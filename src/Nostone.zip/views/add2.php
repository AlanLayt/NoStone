
<div id="map_canvas" class="largeMap"></div>
		  
          
<?php
	if (isset($_GET)) echo var_dump($_GET);
?>